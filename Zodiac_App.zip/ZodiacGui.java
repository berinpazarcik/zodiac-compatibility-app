import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale;

public class ZodiacGui {
    private static ZodiacSign createSign(String name) {
        switch(name.trim().toLowerCase(Locale.ROOT)) {
            case "aries": return new Aries();
            case "taurus": return new Taurus();
            case "gemini": return new Gemini();
            case "cancer": return new Cancer();
            case "leo": return new Leo();
            case "virgo": return new Virgo();
            case "libra": return new Libra();
            case "scorpio": return new Scorpio();
            case "sagittarius": return new Sagittarius();
            case "capricorn": return new Capricorn();
            case "aquarius": return new Aquarius();
            case "pisces": return new Pisces();
            default: throw new IllegalArgumentException("Unknown sign: " + name);
        }
    }

    private static CompatibilityCalculator createCalculator(String type) {
        switch(type.trim().toLowerCase(Locale.ROOT)) {
            case "friendship": return new FriendshipCalculator();
            case "work": return new WorkCalculator();
            case "romantic": return new RomanticCalculator();
            default: throw new IllegalArgumentException("Unknown relationship type: " + type);
        }
    }

    private static void runCalculation(ZodiacSign u, ZodiacSign o, CompatibilityCalculator calc, JTextArea output) {
        int score = calc.calculateCompatibility(u, o);
        RelationshipType type = calc.determineRelationshipType(score);
        StringBuilder result = new StringBuilder();
        result.append("Comparing: ").append(u.getName()).append(" & ").append(o.getName()).append("\n");
        result.append("Score: ").append(score).append(", Type: ").append(type.toString().replace('_',' ')).append("\n");

        switch (type) {
            case ROMANTIC:
                if (score >= 75)
                    result.append("💘 High romantic compatibility! Deep connection likely.");
                else if (score >= 68)
                    result.append("💑 Promising romance with some shared values.");
                else if (score >= 60)
                    result.append("🙂 Some romantic potential. Give it time.");
                else if (score >= 50)
                    result.append("😕 Mixed signals. Communication is key.");
                else
                    result.append("💔 Challenging match. Strong differences may exist.");
                break;

            case FRIENDSHIP:
                if (score >= 75)
                    result.append("👯 Super strong friendship! You really click.");
                else if (score >= 68)
                    result.append("🤝 Solid bond and mutual respect.");
                else if (score >= 60)
                    result.append("🙂 You get along fine. Could grow stronger.");
                else if (score >= 50)
                    result.append("😐 Some tension, but manageable.");
                else
                    result.append("❗ Friendship might be distant. Respect differences.");
                break;

            case WORK_PARTNERSHIP:
                if (score >= 75)
                    result.append("💼 Excellent team potential. Very compatible.");
                else if (score >= 68)
                    result.append("👍 Good working relationship.");
                else if (score >= 60)
                    result.append("🙂 Could work well with clear communication.");
                else if (score >= 50)
                    result.append("⚠️ Possible friction. Align goals carefully.");
                else
                    result.append("❌ Hard to collaborate. Consider alternative pairings.");
                break;
        }
        output.setText(result.toString());
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Zodiac Compatibility Checker");
        frame.setSize(500, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridLayout(4, 2));
        String[] signs = {"Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo", "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces"};
        JComboBox<String> userSignBox = new JComboBox<>(signs);
        JComboBox<String> otherSignBox = new JComboBox<>(signs);
        String[] types = {"romantic", "friendship", "work"};
        JComboBox<String> relationshipBox = new JComboBox<>(types);

        inputPanel.add(new JLabel("Your Sign:"));
        inputPanel.add(userSignBox);
        inputPanel.add(new JLabel("Other's Sign:"));
        inputPanel.add(otherSignBox);
        inputPanel.add(new JLabel("Relationship Type:"));
        inputPanel.add(relationshipBox);

        JButton checkButton = new JButton("Check Compatibility");
        JTextArea resultArea = new JTextArea();
        resultArea.setWrapStyleWord(true);
        resultArea.setLineWrap(true);
        resultArea.setEditable(false);

        checkButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ZodiacSign user = createSign((String) userSignBox.getSelectedItem());
                ZodiacSign other = createSign((String) otherSignBox.getSelectedItem());
                CompatibilityCalculator calc = createCalculator((String) relationshipBox.getSelectedItem());
                runCalculation(user, other, calc, resultArea);
            }
        });

        JPanel bottomPanel = new JPanel();
        bottomPanel.add(checkButton);

        frame.add(inputPanel, BorderLayout.NORTH);
        frame.add(new JScrollPane(resultArea), BorderLayout.CENTER);
        frame.add(bottomPanel, BorderLayout.SOUTH);
        frame.setVisible(true);
    }
}
