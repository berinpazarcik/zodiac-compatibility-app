
import java.util.Locale;
import java.util.Scanner;

interface CompatibilityCalculator {
    int calculateCompatibility(ZodiacSign a, ZodiacSign b);
    RelationshipType determineRelationshipType(int score);
}

abstract class ZodiacSign {
    private String name, element, modality, traits;

    public ZodiacSign(String name, String element, String modality, String traits) {
        this.name = name; this.element = element; this.modality = modality; this.traits = traits;
    }

    public String getName() { return name; }
    public String getElement() { return element; }
    public String getModality() { return modality; }
    public String getTraits() { return traits; }
}

class Aries extends ZodiacSign { public Aries() { super("Aries", "Fire", "Cardinal", "Brave and energetic"); } }
class Taurus extends ZodiacSign { public Taurus() { super("Taurus", "Earth", "Fixed", "Patient and reliable"); } }
class Gemini extends ZodiacSign { public Gemini() { super("Gemini", "Air", "Mutable", "Witty and curious"); } }
class Cancer extends ZodiacSign { public Cancer() { super("Cancer", "Water", "Cardinal", "Caring and intuitive"); } }
class Leo extends ZodiacSign { public Leo() { super("Leo", "Fire", "Fixed", "Confident and loyal"); } }
class Virgo extends ZodiacSign { public Virgo() { super("Virgo", "Earth", "Mutable", "Analytical and kind"); } }
class Libra extends ZodiacSign { public Libra() { super("Libra", "Air", "Cardinal", "Balanced and diplomatic"); } }
class Scorpio extends ZodiacSign { public Scorpio() { super("Scorpio", "Water", "Fixed", "Intense and passionate"); } }
class Sagittarius extends ZodiacSign { public Sagittarius() { super("Sagittarius", "Fire", "Mutable", "Adventurous and honest"); } }
class Capricorn extends ZodiacSign { public Capricorn() { super("Capricorn", "Earth", "Cardinal", "Disciplined and responsible"); } }
class Aquarius extends ZodiacSign { public Aquarius() { super("Aquarius", "Air", "Fixed", "Independent and visionary"); } }
class Pisces extends ZodiacSign { public Pisces() { super("Pisces", "Water", "Mutable", "Empathetic and dreamy"); } }

enum RelationshipType {
    FRIENDSHIP, WORK_PARTNERSHIP, ROMANTIC
}

class RomanticCalculator implements CompatibilityCalculator {
    public int calculateCompatibility(ZodiacSign a, ZodiacSign b) {
        String[] traitsA = a.getTraits().toLowerCase().split(" ");
        String[] traitsB = b.getTraits().toLowerCase().split(" ");
        int matchCount = 0;
        for (String wordA : traitsA)
            for (String wordB : traitsB)
                if (wordA.equals(wordB)) matchCount++;

        int traitScore = Math.min(10 + (matchCount * 5), 25);

        int elementScore;
        String e1 = a.getElement(), e2 = b.getElement();
        if (e1.equals(e2)) elementScore = 10;
        else if ((e1.equals("Water") && e2.equals("Earth")) || (e1.equals("Earth") && e2.equals("Water")) ||
                 (e1.equals("Fire") && e2.equals("Air")) || (e1.equals("Air") && e2.equals("Fire")))
            elementScore = 5;
        else elementScore = -5;

        int modalityScore;
        String m1 = a.getModality(), m2 = b.getModality();
        if (m1.equals(m2)) modalityScore = 10;
        else if ((m1.equals("Fixed") && m2.equals("Cardinal")) || (m1.equals("Cardinal") && m2.equals("Fixed")))
            modalityScore = 5;
        else modalityScore = -5;

        int raw = traitScore + elementScore + modalityScore;
        int scaled = Math.max(50, Math.min(100, 50 + (int)((raw * 50.0) / 45.0)));
        return scaled;
    }

    public RelationshipType determineRelationshipType(int score) {
        return RelationshipType.ROMANTIC;
    }
}

class FriendshipCalculator extends RomanticCalculator {
    public RelationshipType determineRelationshipType(int score) {
        return RelationshipType.FRIENDSHIP;
    }
}

class WorkCalculator extends RomanticCalculator {
    public RelationshipType determineRelationshipType(int score) {
        return RelationshipType.WORK_PARTNERSHIP;
    }
}

public class ZodiacApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your zodiac sign: ");
        ZodiacSign user = createSign(scanner.nextLine());
        System.out.print("Enter other person's zodiac sign: ");
        ZodiacSign other = createSign(scanner.nextLine());
        System.out.print("Enter relationship type (friendship, work, romantic): ");
        CompatibilityCalculator calc = createCalculator(scanner.nextLine());
        System.out.println();
        runCalculation(user, other, calc);
        scanner.close();
    }

    private static ZodiacSign createSign(String name) {
        switch(name.trim().toLowerCase(Locale.ROOT)) {
            case "aries": return new Aries();
            case "taurus": return new Taurus();
            case "gemini": return new Gemini();
            case "cancer": return new Cancer();
            case "leo": return new Leo();
            case "virgo": return new Virgo();
            case "libra": return new Libra();
            case "scorpio": return new Scorpio();
            case "sagittarius": return new Sagittarius();
            case "capricorn": return new Capricorn();
            case "aquarius": return new Aquarius();
            case "pisces": return new Pisces();
            default: throw new IllegalArgumentException("Unknown sign: " + name);
        }
    }

    private static CompatibilityCalculator createCalculator(String type) {
        switch(type.trim().toLowerCase(Locale.ROOT)) {
            case "friendship": return new FriendshipCalculator();
            case "work": return new WorkCalculator();
            case "romantic": return new RomanticCalculator();
            default: throw new IllegalArgumentException("Unknown relationship type: " + type);
        }
    }

    private static void runCalculation(ZodiacSign u, ZodiacSign o, CompatibilityCalculator calc) {
        System.out.println("Comparing: " + u.getName() + " & " + o.getName());
        int score = calc.calculateCompatibility(u, o);
        RelationshipType type = calc.determineRelationshipType(score);
        System.out.print("Score: " + score + ", Type: " + type.toString().replace('_',' '));

        switch (type) {
            case ROMANTIC:
                if (score >= 75)
                    System.out.println(" 💘 High romantic compatibility! Deep connection likely.");
                else if (score >= 68)
                    System.out.println(" 💑 Promising romance with some shared values.");
                else if (score >= 60)
                    System.out.println(" 🙂 Some romantic potential. Give it time.");
                else if (score >= 50)
                    System.out.println(" 😕 Mixed signals. Communication is key.");
                else
                    System.out.println(" 💔 Challenging match. Strong differences may exist.");
                break;

            case FRIENDSHIP:
                if (score >= 75)
                    System.out.println(" 👯 Super strong friendship! You really click.");
                else if (score >= 68)
                    System.out.println(" 🤝 Solid bond and mutual respect.");
                else if (score >= 60)
                    System.out.println(" 🙂 You get along fine. Could grow stronger.");
                else if (score >= 50)
                    System.out.println(" 😐 Some tension, but manageable.");
                else
                    System.out.println(" ❗ Friendship might be distant. Respect differences.");
                break;

            case WORK_PARTNERSHIP:
                if (score >= 75)
                    System.out.println(" 💼 Excellent team potential. Very compatible.");
                else if (score >= 68)
                    System.out.println(" 👍 Good working relationship.");
                else if (score >= 60)
                    System.out.println(" 🙂 Could work well with clear communication.");
                else if (score >= 50)
                    System.out.println(" ⚠️ Possible friction. Align goals carefully.");
                else
                    System.out.println(" ❌ Hard to collaborate. Consider alternative pairings.");
                break;
        }
    }
}
